package First;

public class Rectangle {
int side;int area;	
int length;int width;int perimeter;

	void rec() {
		side=12;
		area=side*side;
		length=10;
		width=5;
		perimeter=2*(length+width);
		
	}
	
	public static void main(String args[]) {
		Rectangle obj=new Rectangle();
		obj.rec();
		System.out.println("The area of Rectangle is:"+obj.area);
		System.out.println("Thep perimeter of Rectangle is:"+obj.perimeter);
	}
	
}
