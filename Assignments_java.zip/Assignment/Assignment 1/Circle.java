package First;

public class Circle {
	float pi;
	int r;
	float area;
	float circumference;
	
	int circle() {
		pi=3.14F;
		r=5;
		area=2*pi*r*r;
		circumference=pi*r*r;
		return 0;
	}
   public static void main(String args[]) {
	   
	   Circle obj=new Circle();
	   obj.circle();
	   
	   System.out.println("area of circle:" +obj.area);
	   System.out.println("circumference of circle:" +obj.circumference);
   }
}
