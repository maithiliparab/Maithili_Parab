package controlStatement;
import java.util.Scanner;
public class Palindrome {
	
	public static void main(String args[]){
		System.out.println("Enter a no:");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		int orgnum=num;
		int rev=0;
		
		while(num!=0) {
			rev=rev*10+num%10;
			num=num/10;
		}
		if(orgnum==rev) {
			System.out.println("palindrome no");
		}
		else {
			System.out.println("Not palindrome no");
		}
	}

}
