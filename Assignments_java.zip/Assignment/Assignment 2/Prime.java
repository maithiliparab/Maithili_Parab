package controlStatement;
import java.util.Scanner;
public class Prime {
	int i,j,n;
	String pri="";
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number");
	n=sc.nextInt();

	 for(i=1;i<=n;i++) {
		 int count=0;
		 for(j=i;j>=1;j--) {
			 if(i%j==0) {
				 count=count+1;
			 }
		 }
		 
		 if(count==2) {
			 pri=pri+i+" ";
		 }
		System.out.println(pri);
	 }
}
