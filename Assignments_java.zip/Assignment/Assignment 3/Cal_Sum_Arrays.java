package third;

import java.util.Scanner;

public class Cal_Sum_Arrays {
     public static void main(String args[]) {
    	 int temp=0;
    	 System.out.println("Enter the size of an array:");
    	
    	 Scanner sc=new Scanner(System.in);
    	 int size=sc.nextInt();
    	
    	 int arr[]=new int[size];
    	for(int i=0;i<size;i++) {
    		  arr[i]=sc.nextInt();
    		  temp=temp+arr[i];	 
    		  
    	}
    	 System.out.println("Sum of all array elements is:"+temp);
    	 
    	 int ans=temp/size;
    	 System.out.println("Average of array elements is:"+ans);
     }
}
