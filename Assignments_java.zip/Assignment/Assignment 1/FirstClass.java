package First;
import java.math.*;

public class FirstClass {
	int sum;
	int sub;
	int mul;
	int div;
	
	void add(int a,int b) {
		sum=a+b;
		sub=a-b;
		mul=a*b;
		div=a/b;
		//return sum;
	}
	
	public static void main(String args[]) {
    FirstClass obj=new FirstClass();
	obj.add(3, 2); 
	System.out.println("Addition is"+obj.sum);
	System.out.println("subtraction is"+obj.sub);
	System.out.println("multiplication is"+obj.mul);
	System.out.println("division is"+obj.div);
	
	}

}
