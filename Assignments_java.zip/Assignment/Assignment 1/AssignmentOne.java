package First;
import java.util.Scanner;
public class AssignmentOne {
	
	public static int add(int a,int b) {
		
		return a+b;
		
		}
   
	public static int sub(int a,int b) {
		
		return a-b;
		
		}

	public static int mul(int a,int b) {
		
		return a*b;
		
		}

	public static int div(int a,int b) {
		 
		return a/b;
		
		}
    public static int mod(int a,int b) {
		
		return a%b;
		
		}
    
/*    public static int mod(int a,int b) {
		
  		int add=a+b;
  		int sub=a-b;
  		int mul=a*b;
  		int div=a/b;
  		int mod=a%b;
  		
  		}*/
	
public static void main(String args[]) {
		
	Scanner sc=new Scanner(System.in);
	System.out.println("enter two numbers:");
	int a=sc.nextInt();
	int b=sc.nextInt();
	
	//FirstClass obj=new FirstClass();
	
    //obj.add(a, b)
	
	System.out.println("Addition is"+(add(a,b)));
	System.out.println("subtraction is"+(sub(a,b)));
	System.out.println("Multiplication is"+(mul(a,b)));
	System.out.println("Division is"+(div(a,b)));
	System.out.println("Modulo is"+(mod(a,b)));
	}

}
